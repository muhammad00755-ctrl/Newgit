import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(VentApp());
}

class VentApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VentOrder',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: ProductListPage(),
    );
  }
}

class ProductListPage extends StatelessWidget {
  final products = [
    {'name': 'Вентиляционный короб', 'price': 1200},
    {'name': 'Воздуховод гибкий', 'price': 800},
    {'name': 'Решётка вентиляционная', 'price': 300},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Вентиляция - заказ')),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          final product = products[index];
          return ListTile(
            title: Text(product['name'] as String),
            subtitle: Text('${product['price']} ₽'),
            trailing: const Icon(Icons.add_shopping_cart),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => CheckoutPage(product: product)),
              );
            },
          );
        },
      ),
    );
  }
}

class CheckoutPage extends StatefulWidget {
  final Map<String, Object> product;

  CheckoutPage({required this.product});

  @override
  _CheckoutPageState createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Оформление заказа')),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('Вы выбрали: ${widget.product['name']}'),
          Text('Цена: ${widget.product['price']} ₽'),
          const SizedBox(height: 20),
          AnimatedBuilder(
            animation: _controller,
            builder: (context, child) {
              return CustomPaint(
                size: const Size(200, 50),
                painter: DuctPainter(_controller.value),
              );
            },
          ),
          const SizedBox(height: 40),
          ElevatedButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Заказ отправлен!")));
            },
            child: const Text('Заказать'),
          )
        ],
      ),
    );
  }
}

class DuctPainter extends CustomPainter {
  final double progress;

  DuctPainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.blue
      ..strokeWidth = 5
      ..style = PaintingStyle.stroke;

    final path = Path()..moveTo(0, size.height / 2);
    for (double x = 0; x <= size.width; x += 10) {
      path.lineTo(x, size.height / 2 + 10 * sin((x / size.width * 2 * pi) + progress * 2 * pi));
    }
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant DuctPainter oldDelegate) => oldDelegate.progress != progress;
}
