# VentOrder

Flutter проект для заказа вентиляционных систем (совместим с Dart 3).

## 🚀 Как собрать APK на Codemagic
1. Создай репозиторий на GitHub.
2. Загрузи в репозиторий этот архив **как есть** (файлы окажутся сразу в корне).
3. В Codemagic подключи свой GitHub и выбери этот репозиторий.
4. В Workflow Editor укажи:
   - Platform: Android
   - Build modes: debug
   - Flutter version: stable
5. Нажми **Start build**.
6. После окончания сборки скачай APK и установи на телефон.

❗ Для iOS нужна сборка на Mac (ограничение Apple).
